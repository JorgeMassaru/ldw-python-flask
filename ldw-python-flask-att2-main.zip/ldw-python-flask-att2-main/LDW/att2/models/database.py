from flask_sqlalchemy import SQLAlchemy 

#Criando uma instância do SQLAlchemy
db = SQLAlchemy()

#Classe responsável por criar a entidade "Games" no banco com seus atributos
class Pokemon(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    nome = db.Column(db.String(150))
    tipo = db.Column(db.String(150))
    geracao = db.Column(db.Integer)
    
    #Método contrutor da Classe
    def __init__(self, nome, tipo, geracao):
        self.nome = nome
        self.tipo = tipo
        self.geracao = geracao